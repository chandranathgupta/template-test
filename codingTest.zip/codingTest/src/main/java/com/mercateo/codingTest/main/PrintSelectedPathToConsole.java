package com.mercateo.codingTest.main;

import org.springframework.stereotype.Component;

@Component
public class PrintSelectedPathToConsole implements PrintSelectedPath {

	@Override
	public void printSelectedElements(int[][] dp, int[] ids, int[] weights, int[] prices, int capacity) {
		StringBuilder sb = new StringBuilder("");
		int totPrice = dp[weights.length - 1][capacity];
		for (int i = weights.length - 1; i > 0; i--) {
			if (totPrice != dp[i - 1][capacity]) {
				sb.append(ids[i] + ",");
				capacity -= weights[i];
				totPrice -= prices[i];
			}
		}

		if (totPrice != 0)
			sb.append(ids[0] + ",");
		if(sb.length()>0) {
			System.out.println(sb.substring(0, sb.length()-1));
		}else {
			System.out.println("-");
		}
		
		System.out.println("");
	}

}
