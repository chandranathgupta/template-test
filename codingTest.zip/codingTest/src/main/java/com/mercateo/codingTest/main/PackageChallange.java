package com.mercateo.codingTest.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mercateo.codingTest.validations.InputConstraints;
import com.mercateo.codingTest.validations.InputFileChecker;

@Component
public class PackageChallange {

	@Autowired
	private InputFileChecker inputFileChecker;

	@Autowired
	private InputConstraints inputConstraints;

	@Autowired
	private PackageSolutions packageSolutions;

	@Autowired
	private PrintSelectedPath printSelectedPath;

	public void findMaxPrice(String path) throws Exception {

		if (!inputFileChecker.verifyFileValidity(path)) {
			throw new Exception("NonExistent Path");
		} else {

			// parse files and generate required data for solution

			List<String> readDataList = consumeFileData(path);
			for (String line : readDataList) {
				Object[] requiredInputs = convertToInputs(line);
				
				int maxWeight = (int) requiredInputs[0];
				
				List<Integer> pricesL = (List<Integer>) requiredInputs[1];
				List<Integer> weightsL = (List<Integer>) requiredInputs[2];
				int[] prices = new int[pricesL.size()];
				int[] weights = new int[pricesL.size()];
				IntStream.range(0, pricesL.size()).forEach(i -> {
					prices[i] = pricesL.get(i);
					weights[i] = weightsL.get(i);
				});;
				
				if (inputConstraints.validateConstraints(maxWeight, weights, prices)) {
					packageSolutions.solution(maxWeight, prices, weights, printSelectedPath);
				}
			}

		}

	}

	public List<String> consumeFileData(String path) throws IOException {
		List<String> inList = new ArrayList<>();
		BufferedReader br = Files.newBufferedReader(Paths.get(path));
		String line;
		while ((line = br.readLine()) != null) {
			if(!line.isEmpty()) {
				inList.add(line);
			}
		}
		br.close();
		return inList;
	}

	public Object[] convertToInputs(String line) throws IOException {
		Object[] returnValues = new Object[3];
		String[] ins = line.split(":");
		
		int maxWeight = Integer.parseInt(ins[0].trim());
		Pattern pq = Pattern.compile("(\\d+,\\d+(\\.\\d+)?,€\\d+)");
		Matcher mq = pq.matcher(ins[1].trim());
		int i = 0;
		
		List<Integer> prices = new ArrayList<>();
		List<Integer> weights = new ArrayList<>();

		while (mq.find()) {
			String[] vs = mq.group().split(",");
			weights.add((int) (Double.parseDouble(vs[1])*100));
			prices.add((int) (Double.parseDouble(vs[2].replace("€", ""))));
		}

		returnValues[0] = maxWeight*100;
		returnValues[1] =  prices;
		returnValues[2] = weights;
		return returnValues;

	}

}
