package com.mercateo.codingTest.validations;

import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

import com.mercateo.codingTest.exceptions.ConstrainedViolationException;

@Component
public class InputConstraintsImpl implements InputConstraints {

	@Override
	public boolean validateConstraints(int maxWeight, int[] weights, int[] prices) throws Exception {

		if (maxWeight / 100 > 100)
			throw new ConstrainedViolationException("The maximum weight that a package can hold must be <= 100.");
		if (weights.length != prices.length || prices.length > 15)
			throw new ConstrainedViolationException("There may be up to 15 items you can to choose from.");
		if (IntStream.of(prices).max().getAsInt() > 100)
			throw new ConstrainedViolationException("The maximum weight of an item should be <= 100.");
		if (IntStream.of(weights).max().getAsInt() / 100 > 100)
			throw new ConstrainedViolationException("The maximum weight of an item should be <= 100.");

		return true;
	}

}
