package com.mercateo.codingTest.main;

public interface PackageSolutions {
	public int solution(int maxWeight, int[] pricesIn, int[] weightsIn, PrintSelectedPath ps);
}
