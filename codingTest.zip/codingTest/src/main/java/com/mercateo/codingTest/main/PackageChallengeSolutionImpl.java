package com.mercateo.codingTest.main;

import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

@Component
public class PackageChallengeSolutionImpl implements PackageSolutions{
	
	// the method is final to prohibit overriding
	public final int solution(int maxWeight, int[] pricesIn, int[] weightsIn, PrintSelectedPath ps) {
		
		int[] idsIn = IntStream.range(1, weightsIn.length+1).toArray();
		
		//sorting ascending order to find minimum weight in case where the profit is same.
		int[] prices = IntStream.range(0, weightsIn.length).boxed().sorted(Comparator.comparingInt(i -> weightsIn[i]))
				.mapToInt(i -> pricesIn[i]).toArray();

		int[] weights = IntStream.range(0, weightsIn.length).boxed().sorted(Comparator.comparingInt(i -> weightsIn[i]))
				.mapToInt(i -> weightsIn[i]).toArray();
		
		int[] ids = IntStream.range(0, weightsIn.length).boxed().sorted(Comparator.comparingInt(i -> weightsIn[i]))
				.mapToInt(i -> idsIn[i]).toArray();
		
		// checks minimum base. capacity cannot be less than 0 and weights length should
		// be equal to prices length
		if (maxWeight <= 0 || prices.length == 0 || weights.length != prices.length)
			return 0;

		int n = prices.length;
		int[][] maxPrices = new int[n][maxWeight + 1];

		IntStream.range(0, n).forEach(j -> {
			maxPrices[j][0] = 0;
		});

		// take one weight if not more than capacity
		IntStream.range(0, maxWeight).forEach(s -> {
			if (weights[0] <= s)
				maxPrices[0][s] = prices[0];
		});

		// process all sub-arrays for all the capacities.
		// include the item, if it is not more than the capacity
		for (int i = 1; i < n; i++) {
			for (int c = 1; c <= maxWeight; c++) {
				int profit1 = 0, profit2 = 0;
				if (weights[i] <= c)
					profit1 = prices[i] + maxPrices[i - 1][c - weights[i]];
				profit2 = maxPrices[i - 1][c];
				// max of branch and itself
				maxPrices[i][c] = Math.max(profit1, profit2);
			}
		}
		
		ps.printSelectedElements(maxPrices,ids, weights, prices, maxWeight);

		return maxPrices[n - 1][maxWeight];
	}

	
}
