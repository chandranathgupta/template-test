package com.mercateo.codingTest.validations;

import com.mercateo.codingTest.exceptions.FilePathError;

public interface InputFileChecker{
	public boolean verifyFileValidity(String path)  throws FilePathError  ;
}
