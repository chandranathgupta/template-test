package com.mercateo.codingTest.validations;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mercateo.codingTest.CodingTestApplication;
import com.mercateo.codingTest.exceptions.FilePathError;

@Component
public class InputFileCheckerImpl implements InputFileChecker{
	private static Logger LOG = LoggerFactory
		      .getLogger(CodingTestApplication.class);

	@Override
	public boolean verifyFileValidity(String path) throws FilePathError {
		Path p = Paths.get(path);
		if(Files.exists(p)) {
			try {
				return Files.size(p) > 0;
			} catch (IOException e) {
				LOG.error("Please check if File does exist or File is not empty");
			}
		}else {
			throw new FilePathError("Please check if files exists");
		}
		
		return true;
	}

}
