package com.mercateo.codingTest.main;

public interface PrintSelectedPath {
	public void printSelectedElements(int dp[][], int[] ids, int[] weights, int[] profits, int capacity);
}
