package com.mercateo.codingTest.exceptions;

public class FilePathError extends Exception{
	public FilePathError(String errorMsg) {
		super(errorMsg);
	}

}
