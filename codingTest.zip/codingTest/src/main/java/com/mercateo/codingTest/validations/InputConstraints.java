package com.mercateo.codingTest.validations;


public interface InputConstraints {
	public boolean validateConstraints(int maxWeight, int[] weights, int[] price) throws Exception;
}
