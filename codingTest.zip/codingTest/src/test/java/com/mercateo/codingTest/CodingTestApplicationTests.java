package com.mercateo.codingTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.mercateo.codingTest.main.PackageChallengeSolutionImpl;
import com.mercateo.codingTest.main.PrintSelectedPathToConsole;

@SpringBootTest
class CodingTestApplicationTests {

	@Test
	void testMaxProfit() {

		//Data
			// 56 : (1,90.72,€13) (2,33.80,€40) (3,43.15,€10) (4,37.97,€16)
			// (5,46.81,€36) (6,48.77,€79) (7,81.80,€45) (8,19.36,€79) (9,6.76,€64)
//
//			PackageChallengeSolutionImpl mgt = new PackageChallengeSolutionImpl();
//
//			int[] profits = { 13, 40, 10, 16, 36, 79, 45, 79, 64 };
//			int[] weights = { 9072, 3380, 4315, 3797, 4681, 4877, 8180, 1936, 676 };
//			// 9072		3379 		4315		3797		4681		4877		8180		1936		676
//			Arrays.stream(weights).forEach(a -> System.out.println(a));
//			int maxProfit = mgt.solution(5600, profits, weights, new PrintSelectedPathToConsole());
//			assertEquals(76, maxProfit);
	}

}
