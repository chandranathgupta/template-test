package com.mercateo.codingTest.exceptions;

public class ConstrainedViolationException extends Exception {
    public ConstrainedViolationException(String error) {
    	super(error);
    }
}
