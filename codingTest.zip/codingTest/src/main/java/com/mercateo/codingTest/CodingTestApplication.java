package com.mercateo.codingTest;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.mercateo.codingTest.exceptions.ConstrainedViolationException;
import com.mercateo.codingTest.exceptions.FilePathError;
import com.mercateo.codingTest.main.PackageChallange;

@SpringBootApplication
public class CodingTestApplication implements CommandLineRunner {

	@Autowired
	private PackageChallange packageChallange;

	@Autowired
	private ConfigurableApplicationContext context;

	public static void main(String[] args) {
		SpringApplication.run(CodingTestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Please enter input file path: ");
		Scanner scanner = null;
		try {
			scanner = new Scanner(System.in);
			String pathLine = scanner.nextLine();
			System.out.println(pathLine);
			packageChallange.findMaxPrice(pathLine);
			SpringApplication.exit(context);
		} catch (FilePathError | ConstrainedViolationException e) {
			System.out.println(e.getMessage());
		} finally {
			scanner.close();
		}

	}

}
